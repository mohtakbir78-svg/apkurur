package com.example.floatingbrowser

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        column.addView(TextView(this).apply {
            text = "Browser Mengambang"
            textSize = 24f
        })

        column.addView(TextView(this).apply {
            text = "Buka browser kecil yang melayang di atas game atau aplikasi apa pun, " +
                "bisa digeser, diubah ukurannya, dan dibuat transparan.\n\n" +
                "Langkah: 1) beri izin overlay, 2) tekan Mulai, 3) buka game kamu."
            setPadding(0, pad / 2, 0, pad / 2)
        })

        status = TextView(this).apply { setPadding(0, 0, 0, pad / 2) }
        column.addView(status)

        column.addView(Button(this).apply {
            text = "1. Beri izin overlay"
            setOnClickListener { openOverlaySettings() }
        })

        column.addView(Button(this).apply {
            text = "2. Mulai browser mengambang"
            setOnClickListener { startOverlay() }
        })

        column.addView(Button(this).apply {
            text = "Hentikan"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })

        setContentView(ScrollView(this).apply { addView(column) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this)) {
            "Status izin overlay: AKTIF"
        } else {
            "Status izin overlay: BELUM diberikan"
        }
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Beri izin overlay dulu", Toast.LENGTH_SHORT).show()
            openOverlaySettings()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)
    }
}
