package com.example.floatingbrowser

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

/**
 * Jendela browser melayang di atas aplikasi/game apa pun.
 *
 * Fitur:
 *  - geser: tarik bar gelap di bagian atas
 *  - ubah ukuran: tarik sudut kanan-bawah (◢)
 *  - transparan: tombol ◐ (4 tingkat)
 *  - minimize jadi bubble 🌐: tombol –  (ketuk bubble untuk membuka lagi)
 *  - mode ketik: tombol ⌨ (aktifkan kalau mau mengetik di halaman web)
 *
 * Catatan: saat "mode ketik" mati, jendela tidak mengambil fokus, jadi game di
 * belakang tetap berjalan normal. Saat mode ketik hidup, sebagian game bisa pause.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.floatingbrowser.STOP"
        private const val CHANNEL_ID = "overlay_browser"
        private const val NOTIF_ID = 1
        private const val HOME_URL = "https://www.google.com"
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    }

    private lateinit var wm: WindowManager
    private lateinit var windowView: FrameLayout
    private lateinit var bubbleView: TextView
    private lateinit var webView: WebView
    private lateinit var urlBar: EditText
    private lateinit var keyboardButton: TextView
    private lateinit var windowParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private var windowShown = false
    private var bubbleShown = false
    private var alphaIndex = 0
    private val alphaSteps = floatArrayOf(1f, 0.75f, 0.5f, 0.3f)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        buildWindow()
        buildBubble()
        showWindow()
        webView.loadUrl(HOME_URL)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hideWindow()
        hideBubble()
        webView.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notifikasi

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Browser mengambang", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Hentikan",
            stopIntent
        ).build()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Browser mengambang aktif")
            .setContentText("Ketuk Hentikan untuk menutup")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(stopAction)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    // ------------------------------------------------------------------- jendela

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun buildWindow() {
        val dm = resources.displayMetrics
        windowParams = WindowManager.LayoutParams(
            (dm.widthPixels * 0.92f).toInt(),
            (dm.heightPixels * 0.5f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(60)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        }

        windowView = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(10).toFloat()
                setStroke(dp(2), 0xFF37474F.toInt())
            }
        }

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // Bar geser
        val handle = TextView(this).apply {
            text = "━━━  geser di sini  ━━━"
            gravity = Gravity.CENTER
            textSize = 11f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF37474F.toInt())
            setPadding(0, dp(6), 0, dp(6))
        }
        column.addView(handle, LinearLayout.LayoutParams(MATCH, WRAP))
        attachDrag(handle, windowParams, windowView)

        // Bar alamat + tombol
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFFECEFF1.toInt())
        }

        urlBar = EditText(this).apply {
            setSingleLine(true)
            textSize = 13f
            setText(HOME_URL)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN && !windowFocusable()) {
                    setWindowFocusable(true)
                    postDelayed({
                        requestFocus()
                        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                        imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
                    }, 150)
                }
                false
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    loadFromBar()
                    true
                } else {
                    false
                }
            }
        }

        bar.addView(barButton("◀") { if (webView.canGoBack()) webView.goBack() })
        bar.addView(urlBar, LinearLayout.LayoutParams(0, WRAP, 1f))
        keyboardButton = barButton("⌨") { setWindowFocusable(!windowFocusable()) }
        bar.addView(keyboardButton)
        bar.addView(barButton("◐") { cycleAlpha() })
        bar.addView(barButton("–") { minimize() })
        bar.addView(barButton("✕") { stopSelf() })
        column.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        // WebView
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    if (url != null && !urlBar.hasFocus()) urlBar.setText(url)
                }
            }
            webChromeClient = WebChromeClient()
        }
        column.addView(webView, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Pegangan ubah ukuran (sudut kanan-bawah)
        val resize = TextView(this).apply {
            text = "◢"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(0xFF37474F.toInt())
            setBackgroundColor(0x66FFFFFF)
        }
        var startW = 0
        var startH = 0
        var touchX = 0f
        var touchY = 0f
        resize.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startW = windowParams.width
                    startH = windowParams.height
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    windowParams.width = max(dp(180), startW + (e.rawX - touchX).toInt())
                    windowParams.height = max(dp(160), startH + (e.rawY - touchY).toInt())
                    wm.updateViewLayout(windowView, windowParams)
                }
            }
            true
        }

        windowView.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        windowView.addView(
            resize,
            FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.END)
        )
    }

    private fun buildBubble() {
        bubbleView = TextView(this).apply {
            text = "🌐"
            textSize = 22f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC37474F.toInt())
            }
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(52), dp(52),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            BASE_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }
        attachDrag(bubbleView, bubbleParams, bubbleView) { restore() }
    }

    // ------------------------------------------------------------------- aksi

    private fun showWindow() {
        if (!windowShown) {
            wm.addView(windowView, windowParams)
            windowShown = true
        }
    }

    private fun hideWindow() {
        if (windowShown) {
            wm.removeView(windowView)
            windowShown = false
        }
    }

    private fun showBubble() {
        if (!bubbleShown) {
            wm.addView(bubbleView, bubbleParams)
            bubbleShown = true
        }
    }

    private fun hideBubble() {
        if (bubbleShown) {
            wm.removeView(bubbleView)
            bubbleShown = false
        }
    }

    private fun minimize() {
        setWindowFocusable(false)
        hideWindow()
        showBubble()
    }

    private fun restore() {
        hideBubble()
        showWindow()
    }

    private fun cycleAlpha() {
        alphaIndex = (alphaIndex + 1) % alphaSteps.size
        windowParams.alpha = alphaSteps[alphaIndex]
        if (windowShown) wm.updateViewLayout(windowView, windowParams)
    }

    private fun windowFocusable(): Boolean =
        windowParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE == 0

    private fun setWindowFocusable(focusable: Boolean) {
        if (!focusable) hideKeyboard()
        windowParams.flags = if (focusable) {
            windowParams.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            windowParams.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        if (windowShown) wm.updateViewLayout(windowView, windowParams)
        keyboardButton.setBackgroundColor(if (focusable) 0xFFFFC107.toInt() else Color.TRANSPARENT)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
    }

    private fun loadFromBar() {
        val raw = urlBar.text.toString().trim()
        if (raw.isEmpty()) return
        val url = when {
            raw.startsWith("http://") || raw.startsWith("https://") -> raw
            raw.contains(" ") || !raw.contains(".") ->
                "https://www.google.com/search?q=" + Uri.encode(raw)
            else -> "https://$raw"
        }
        webView.loadUrl(url)
        setWindowFocusable(false)
    }

    // ------------------------------------------------------------------ util

    private fun barButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        gravity = Gravity.CENTER
        setPadding(dp(9), dp(6), dp(9), dp(6))
        setOnClickListener { onClick() }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDrag(
        handle: View,
        lp: WindowManager.LayoutParams,
        target: View,
        onTap: (() -> Unit)? = null
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    lp.x = startX + dx
                    lp.y = startY + dy
                    wm.updateViewLayout(target, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
        ).toInt()
}
